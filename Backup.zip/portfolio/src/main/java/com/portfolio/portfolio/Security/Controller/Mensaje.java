package com.portfolio.portfolio.Security.Controller;

public class Mensaje {
    private String mensaje;
    
    //constructores

    public Mensaje() {
    }

    public Mensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    //constructores
    
    //getters y setters

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    //getters y setters
}

